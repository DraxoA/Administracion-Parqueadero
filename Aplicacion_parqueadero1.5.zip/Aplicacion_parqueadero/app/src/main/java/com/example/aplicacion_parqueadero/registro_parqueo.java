package com.example.aplicacion_parqueadero;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class registro_parqueo extends AppCompatActivity {
    RequestQueue requestQueue;
    String cedulaempleado=null;
    String placa=null;
    EditText edtHora_entrada,edtHora_salida,edtFecha,edtPagar;
    Button btnRegistrarparqueo;
    AutoCompleteTextView desplegable1;
    AutoCompleteTextView desplegable2;
    ArrayAdapter<String> adapterItems1;
    ArrayAdapter<String> adapterItems2;
    ArrayList<String> placas= new ArrayList<>();
    ArrayList<String> CedulasEmpleados= new ArrayList<>();

    String ip=Globalinfo.ip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro_parqueo);

        edtHora_entrada=(EditText)findViewById(R.id.editTextHora_entrada);
        edtHora_salida=(EditText)findViewById(R.id.editHora_salida);
        edtFecha=(EditText)findViewById(R.id.editTextFecha);
        edtPagar=(EditText)findViewById(R.id.editTextTotal_pagar);
        btnRegistrarparqueo=(Button)findViewById(R.id.btn_registroParqueo);

        cargarPlacas("http://"+ip+":8080/developDiego/getPlaca_vehiculos.php");

        desplegable1 = findViewById(R.id.editTextPlaca2);
        adapterItems1= new ArrayAdapter<String>(this,R.layout.list_item,placas);
        desplegable1.setAdapter(adapterItems1);
        desplegable1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "Item: "+item,Toast.LENGTH_SHORT).show();
                placa=item.toString();
            }
        });

        cargarCedulas("http://"+ip+":8080/developDiego/getId_empleados.php");

        desplegable2 = findViewById(R.id.editTextCedulaEmpleado);
        adapterItems2= new ArrayAdapter<String>(this,R.layout.list_item,CedulasEmpleados);
        desplegable2.setAdapter(adapterItems2);
        desplegable2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "Item: "+item,Toast.LENGTH_SHORT).show();
                cedulaempleado=item.toString();
            }
        });

        btnRegistrarparqueo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ejecutarServicio("http://"+ip+":8080/developDiego/insertar_parqueo.php");
            }
        });

    }
    private void cargarPlacas(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        //Aqui debo poner lo del array
                        placas.add(jsonObject.getString("Placa"));
                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Error de conexion",Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    private void cargarCedulas(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        //Aqui debo poner lo del array
                        CedulasEmpleados.add(jsonObject.getString("Cedula"));
                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Error de conexion",Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    private void ejecutarServicio(String URL){
        StringRequest stringRequest= new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion Exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("placa_vehiculo",placa);
                parametros.put("cedula_empleado",cedulaempleado);
                parametros.put("hora_entrada",edtHora_entrada.getText().toString());
                parametros.put("hora_salida",edtHora_salida.getText().toString());
                parametros.put("totalpagar",edtPagar.getText().toString());
                parametros.put("fecha_parqueo",edtFecha.getText().toString());
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

}