package com.example.aplicacion_parqueadero;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.content.Intent;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class empleados extends AppCompatActivity {
    EditText edtNombre2,edtApellido2,edtTelefono2,edtCedula2;
    Button btnRegistrarEmpleado;
    String ip=Globalinfo.ip;
    AutoCompleteTextView desplegable;
    ArrayAdapter<String> adapterItems;
    String [] items={"Diurno","Nocturno"};
    String turno=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.empleados);

        edtNombre2=(EditText)findViewById(R.id.editTextNombre2);
        edtApellido2=(EditText)findViewById(R.id.editTextApellido2);
        edtTelefono2=(EditText)findViewById(R.id.editTextTelefono2);
        edtCedula2=(EditText)findViewById(R.id.editTextCedula2);
        btnRegistrarEmpleado=(Button)findViewById(R.id.btn_registroEmpleados);

        desplegable = findViewById(R.id.editTextTurno);
        adapterItems= new ArrayAdapter<String>(this,R.layout.list_item,items);
        desplegable.setAdapter(adapterItems);
        desplegable.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "Item: "+item,Toast.LENGTH_SHORT).show();
                turno=item.toString();
            }
        });

        btnRegistrarEmpleado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                boolean camposValidos = true;

                if (edtNombre2.getText().toString().trim().isEmpty()) {
                    edtNombre2.setBackgroundColor(Color.parseColor("#FFCDD2")); // rojo claro
                    camposValidos = false;
                } else {
                    edtNombre2.setBackgroundColor(Color.parseColor("#FFFFFFFF")); ;
                }

                if (edtApellido2.getText().toString().trim().isEmpty()) {
                    edtApellido2.setBackgroundColor(Color.parseColor("#FFCDD2"));
                    camposValidos = false;
                } else {
                    edtApellido2.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                }
                if (edtTelefono2.getText().toString().trim().isEmpty()) {
                    edtTelefono2.setBackgroundColor(Color.parseColor("#FFCDD2"));
                    camposValidos = false;
                } else {
                    edtTelefono2.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                }
                if (edtCedula2.getText().toString().trim().isEmpty()) {
                    edtCedula2.setBackgroundColor(Color.parseColor("#FFCDD2"));
                    camposValidos = false;
                } else {
                    edtCedula2.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                }

                if (!camposValidos) {
                    Toast.makeText(empleados.this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }
                ejecutarServicio("http://"+ip+"/developDiego/insertar_empleados.php");
            }
        });
    }

    private void ejecutarServicio(String URL){
        StringRequest stringRequest= new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion Exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("nombre_empleado",edtNombre2.getText().toString());
                parametros.put("apellido_empleado",edtApellido2.getText().toString());
                parametros.put("turno_empleado",turno);
                parametros.put("telefono_cliente",edtTelefono2.getText().toString());
                parametros.put("cedula_cliente",edtCedula2.getText().toString());
                return parametros;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
