package com.example.aplicacion_parqueadero;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class registro_entradas extends AppCompatActivity {
    EditText edtPlaca;
    Button btn_Placa_Entrante;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.placa_entrada);
        edtPlaca=(EditText) findViewById(R.id.editTextPLacaEntrante);
        btn_Placa_Entrante=(Button)findViewById(R.id.btn_Placa_Entrante);
        btn_Placa_Entrante.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean camposValidos = true;

                if (edtPlaca.getText().toString().trim().isEmpty()) {
                    edtPlaca.setBackgroundColor(Color.parseColor("#FFCDD2")); // rojo claro
                    camposValidos = false;
                } else {
                    edtPlaca.setBackgroundColor(Color.parseColor("#FFFFFFFF")); ;
                }

                if (!camposValidos) {
                    Toast.makeText(registro_entradas.this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                edtPlaca.setText("");

                edtPlaca.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;

            }
        });
    }
}
