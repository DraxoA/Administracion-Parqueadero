package com.example.aplicacion_parqueadero;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class registro_salida extends AppCompatActivity {
    EditText edtPlaca;
    Button btn_Placa_Saliente;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.placa_salida);
        edtPlaca=(EditText) findViewById(R.id.editTextPLacaSaliente);
        btn_Placa_Saliente=(Button)findViewById(R.id.btn_registroSaliente);
        btn_Placa_Saliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean camposValidos = true;

                if (edtPlaca.getText().toString().trim().isEmpty()) {
                    edtPlaca.setBackgroundColor(Color.parseColor("#FFCDD2")); // rojo claro
                    camposValidos = false;
                } else {
                    edtPlaca.setBackgroundColor(Color.parseColor("#FFFFFFFF")); ;
                }

                if (!camposValidos) {
                    Toast.makeText(registro_salida.this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                edtPlaca.setText("");

                edtPlaca.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;

            }
        });
    }
}