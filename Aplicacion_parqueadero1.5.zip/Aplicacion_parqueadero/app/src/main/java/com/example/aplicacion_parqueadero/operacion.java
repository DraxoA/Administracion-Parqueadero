package com.example.aplicacion_parqueadero;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class operacion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.operacion);
    }

    public void onClick(View view){
        Intent irLayout=null;
        if(view.getId()==R.id.btnEntradas){
            irLayout= new Intent(operacion.this,registro_entradas.class);
        }
        if(view.getId()==R.id.btnSalidas){
            irLayout= new Intent(operacion.this,registro_salida.class);
        }
        startActivity(irLayout);
    }
}
