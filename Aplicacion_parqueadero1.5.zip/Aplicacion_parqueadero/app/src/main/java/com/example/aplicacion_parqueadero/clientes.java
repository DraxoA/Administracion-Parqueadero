package com.example.aplicacion_parqueadero;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import android.graphics.Color;

public class clientes extends AppCompatActivity {
    EditText edtNombre,edtApellido,edtTelefono,edtCedula;
    Button btnRegistrarCliente;
    String ip=Globalinfo.ip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clientes);
        edtNombre=(EditText)findViewById(R.id.editTextNombre1);
        edtApellido=(EditText)findViewById(R.id.editTextApellido1);
        edtTelefono=(EditText)findViewById(R.id.editTextTelefono1);
        edtCedula=(EditText)findViewById(R.id.editTextCedula1);
        btnRegistrarCliente=(Button)findViewById(R.id.btn_registroclientes);

        btnRegistrarCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean camposValidos = true;

                if (edtNombre.getText().toString().trim().isEmpty()) {
                    edtNombre.setBackgroundColor(Color.parseColor("#FFCDD2")); // rojo claro
                    camposValidos = false;
                } else {
                    edtNombre.setBackgroundColor(Color.parseColor("#FFFFFFFF")); ;
                }

                if (edtCedula.getText().toString().trim().isEmpty()) {
                    edtCedula.setBackgroundColor(Color.parseColor("#FFCDD2"));
                    camposValidos = false;
                } else {
                    edtCedula.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                }
                if (edtApellido.getText().toString().trim().isEmpty()) {
                    edtApellido.setBackgroundColor(Color.parseColor("#FFCDD2"));
                    camposValidos = false;
                } else {
                    edtApellido.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                }
                if (edtTelefono.getText().toString().trim().isEmpty()) {
                    edtTelefono.setBackgroundColor(Color.parseColor("#FFCDD2"));
                    camposValidos = false;
                } else {
                    edtTelefono.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                }

                if (!camposValidos) {
                    Toast.makeText(clientes.this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                ejecutarServicio();

                // Si todo está bien, limpiar los campos
                edtNombre.setText("");
                edtCedula.setText("");
                edtApellido.setText("");
                edtTelefono.setText("");
                edtNombre.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                edtCedula.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                edtApellido.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                edtTelefono.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
            }
        });
    }
    private void ejecutarServicio(){
        String Nombre=edtNombre.getText().toString().trim();
        String Apellido=edtApellido.getText().toString().trim();
        String Cedula=edtCedula.getText().toString().trim();
        String Telefono=edtTelefono.getText().toString().trim();

        StringRequest request=new StringRequest(Request.Method.POST, "http://"+ip+"/developDiego/insertar_clientes.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.equalsIgnoreCase("datas insertadas")){
                    Toast.makeText(clientes.this, "Registrado Correctamente", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(),clientes.class));
                    finish();
                }else{
                    Toast.makeText(clientes.this, "Registrado Correctamente", Toast.LENGTH_SHORT).show();
                }
            }
        },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(clientes.this,error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("cedula_cliente",Cedula);
                parametros.put("nombre_cliente",Nombre);
                parametros.put("apellido_cliente",Apellido);
                parametros.put("telefono_cliente",Telefono);
                return parametros;
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(clientes.this);
        requestQueue.add(request);
    }
}

