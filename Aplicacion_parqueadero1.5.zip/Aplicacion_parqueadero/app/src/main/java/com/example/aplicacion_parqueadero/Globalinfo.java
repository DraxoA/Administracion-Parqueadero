package com.example.aplicacion_parqueadero;

public class Globalinfo {
    public static String ip = "192.168.150.4";
}
