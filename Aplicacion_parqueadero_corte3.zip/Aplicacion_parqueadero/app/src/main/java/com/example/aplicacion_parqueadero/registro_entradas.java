package com.example.aplicacion_parqueadero;

import android.app.Activity;
import android.content.Intent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class registro_entradas extends AppCompatActivity {
    EditText edtPlaca;
    EditText HORA;


    RequestQueue requestQueue;
    Button btn_Placa_Entrante;
    Button PARQUEO;
    String ip=Globalinfo.ip;
    String Tipo="Hora";
    String cedulaCliente="0";
    String MODELO="NN";
    String MARCA="NN";
    TextView Modalidad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.placa_entrada);
        edtPlaca = (EditText) findViewById(R.id.editTextPLacaEntrante);
        HORA = (EditText) findViewById(R.id.editTextFecha_Hora_entrada);

        Modalidad = (TextView) findViewById(R.id.modalidad);
        PARQUEO = (Button) findViewById(R.id.btn_registroParqueo);

        btn_Placa_Entrante = (Button) findViewById(R.id.btn_Placa_Entrante);
        btn_Placa_Entrante.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                boolean camposValidos = true;

                if (edtPlaca.getText().toString().trim().isEmpty()) {
                    edtPlaca.setBackgroundColor(Color.parseColor("#FFCDD2")); // rojo claro
                    camposValidos = false;
                } else {
                    edtPlaca.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
                    ;
                }

                if (!camposValidos) {
                    Toast.makeText(registro_entradas.this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                ejecutarServicio("http://" + ip + "/developDiego/Obtener_placas.php");
                edtPlaca.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
                LocalDateTime fechaHoraActual = LocalDateTime.now();
                String fechaFormateada = fechaHoraActual.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                HORA.setText(fechaFormateada);
                btn_Placa_Entrante.setVisibility(View.GONE);
                Modalidad.setVisibility(View.VISIBLE);
                HORA.setVisibility(View.VISIBLE);
                PARQUEO.setVisibility(View.VISIBLE);
                String PLACA = edtPlaca.getText().toString().trim();

                PARQUEO.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String URL="http://"+ip+"/developDiego/verificar_entrada.php?placa="+PLACA;
                        RequestQueue queue = Volley.newRequestQueue(registro_entradas.this);

                        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                                response -> {
                                    try {
                                        JSONObject jsonObject = new JSONObject(response);
                                        String estado = jsonObject.getString("estado");

                                        if ("existe".equals(estado)) {
                                            Toast.makeText(registro_entradas.this, "El vehículo ya está dentro del parqueadero", Toast.LENGTH_SHORT).show();
                                        } else {
                                            Toast.makeText(registro_entradas.this, "El vehículo puede entrar", Toast.LENGTH_SHORT).show();
                                            insertar_entradas("http://"+ip+"/developDiego/insertar_entradas.php");
                                            edtPlaca.setText("");
                                            HORA.setText("");
                                            // Aquí puedes llamar tu función para registrar entrada
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        Toast.makeText(registro_entradas.this, "Error en la respuesta", Toast.LENGTH_SHORT).show();
                                    }
                                },
                                error -> {
                                    Toast.makeText(registro_entradas.this, "Error al conectar con el servidor", Toast.LENGTH_SHORT).show();
                                });

                        queue.add(stringRequest);
                    }
                });
                }
            });

    }

    private void ejecutarServicio(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                boolean placaEncontrada = false;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        if(edtPlaca.getText().toString().equalsIgnoreCase(jsonObject.getString("placa"))){
                            Toast.makeText(registro_entradas.this, "Vehiculo encontrado", Toast.LENGTH_SHORT).show();
                            placaEncontrada = true; // Marcar como encontrada
                            Modalidad.setText(Modalidad.getText()+jsonObject.getString("tipo")+"\n");
                            break; // Salir del bucle si ya se encontró
                        }
                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                if (!placaEncontrada) {
                    insertar_vehiculos("http://"+ip+"/developDiego/insertar_vehiculos.php");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Error de conexion",Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
    private void insertar_vehiculos(String URL){
        String PLACA=edtPlaca.getText().toString().trim();
        Modalidad.setText(Modalidad.getText()+"Hora");
        StringRequest stringRequest= new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion Exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("cedula_dueño",cedulaCliente);
                parametros.put("placa_vehiculo",PLACA);
                parametros.put("modelo_vehiculo",MODELO);
                parametros.put("marca_vehiculo",MARCA);
                parametros.put("Tipo_Cliente",Tipo);
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void insertar_entradas(String URL){
        String PLACA=edtPlaca.getText().toString().trim();
        String DATE=HORA.getText().toString().trim();

        StringRequest stringRequest= new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion Exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("placa_vehiculo",PLACA);
                parametros.put("dateTime",DATE);
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
