package com.example.aplicacion_parqueadero;

public class Globalinfo {
    public static String ip = "192.168.78.4";
    public static float tarifa = 2800;
}
