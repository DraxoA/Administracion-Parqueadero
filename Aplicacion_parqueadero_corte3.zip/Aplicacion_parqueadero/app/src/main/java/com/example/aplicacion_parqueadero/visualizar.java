package com.example.aplicacion_parqueadero;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class visualizar extends AppCompatActivity {
    Button btnVerClientes, btnVerEmpleados,btnVerVehiculos, btnVerParqueos;
    RequestQueue requestQueue;
    TextView Busqueda;
    String ip=Globalinfo.ip;
    String URL="http://"+ip+"/developDiego/Obtener_tabla.php?tabla=";
    String tabla=null;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.visualizar);

        btnVerClientes = (Button) findViewById(R.id.btnverClientes);
        btnVerEmpleados = (Button) findViewById(R.id.btnverEmpleados);
        btnVerVehiculos = (Button) findViewById(R.id.btnverVehiculos);
        btnVerParqueos = (Button) findViewById(R.id.btnverParqueos);

        Busqueda=(TextView)findViewById(R.id.Descripcion);

        btnVerClientes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Busqueda.setText("");
                tabla="clientes";
                ejecutarServicio(URL,tabla);
                }
            });

        btnVerEmpleados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Busqueda.setText("");
                tabla="empleados";
                ejecutarServicio(URL,tabla);
            }
        });

        btnVerVehiculos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Busqueda.setText("");
                tabla="vehiculos";
                ejecutarServicio(URL,tabla);
            }
        });

        btnVerParqueos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Busqueda.setText("");
                tabla="salidas";
                ejecutarServicio(URL,tabla);
            }
        });
        }
        public void ejecutarServicio(String URL,String tabla){
        URL=URL+tabla;
            JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    JSONObject jsonObject = null;
                    for (int i = 0; i < response.length(); i++) {
                        try {
                            jsonObject = response.getJSONObject(i);
                            if (tabla=="clientes"){
                                Busqueda.setText(Busqueda.getText()+"Nombre: "+jsonObject.getString("nombre")+"\n");
                                Busqueda.setText(Busqueda.getText()+"Apellido: "+jsonObject.getString("apellido")+"\n");
                                Busqueda.setText(Busqueda.getText()+"Telefono: "+jsonObject.getString("telefono")+"\n");
                                Busqueda.setText(Busqueda.getText()+"Cedula: "+jsonObject.getString("cedula")+"\n\n");
                            }
                            if (tabla=="empleados"){
                                Busqueda.setText(Busqueda.getText()+"Nombre: "+jsonObject.getString("nombre")+"\n");
                                Busqueda.setText(Busqueda.getText()+"Apellido: "+jsonObject.getString("apellido")+"\n");
                                Busqueda.setText(Busqueda.getText()+"Telefono: "+jsonObject.getString("telefono")+"\n");
                                Busqueda.setText(Busqueda.getText()+"Cedula: "+jsonObject.getString("cedula")+"\n");
                                Busqueda.setText(Busqueda.getText()+"Turno: "+jsonObject.getString("turno")+"\n\n");

                            }if (tabla=="vehiculos"){
                                Busqueda.setText(Busqueda.getText()+"PLaca: "+jsonObject.getString("placa")+"\n");
                                Busqueda.setText(Busqueda.getText()+"Modelo: "+jsonObject.getString("modelo")+"\n");
                                Busqueda.setText(Busqueda.getText()+"Marca: "+jsonObject.getString("marca")+"\n");
                                Busqueda.setText(Busqueda.getText()+"Cliente: "+jsonObject.getString("cedula_cliente")+"\n\n");
                            }
                            if (tabla=="salidas"){
                                Busqueda.setText(Busqueda.getText()+"Fecha: "+jsonObject.getString("fecha_hora_salida").toString()+"\n");
                                Busqueda.setText(Busqueda.getText()+"Placa: "+jsonObject.getString("placa").toString()+"\n");
                                Busqueda.setText(Busqueda.getText()+"Valor: "+jsonObject.getString("cobrado").toString()+"\n\n");

                            }


                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "Error de conexion", Toast.LENGTH_SHORT).show();
                }
            });
            requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(jsonArrayRequest);
        }
}

