package com.example.aplicacion_parqueadero;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.Nullable;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.android.volley.toolbox.JsonArrayRequest;

import java.util.HashMap;
import java.util.Map;

public class registro_salida extends AppCompatActivity {
    EditText edtPlaca;
    EditText HORA;
    TextView modalidad;
    TextView precio;
    Button btn_Placa_Saliente;
    String ip=Globalinfo.ip;
    float tarifa=Globalinfo.tarifa;
    RequestQueue requestQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.placa_salida);
        edtPlaca=(EditText) findViewById(R.id.editTextPLacaSaliente);
        HORA=(EditText) findViewById(R.id.editTextFecha_Hora_salida);
        LocalDateTime fechaHoraActual = LocalDateTime.now();
        String fechaFormateada = fechaHoraActual.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        HORA.setText(fechaFormateada);
        modalidad=(TextView)findViewById(R.id.modalidad);
        precio=(TextView)findViewById(R.id.Cobrar);
        btn_Placa_Saliente=(Button)findViewById(R.id.btn_registroSaliente);
        btn_Placa_Saliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean camposValidos = true;

                if (edtPlaca.getText().toString().trim().isEmpty()) {
                    edtPlaca.setBackgroundColor(Color.parseColor("#FFCDD2")); // rojo claro
                    camposValidos = false;
                } else {
                    edtPlaca.setBackgroundColor(Color.parseColor("#FFFFFFFF")); ;
                }

                if (!camposValidos) {
                    Toast.makeText(registro_salida.this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }
                VerificarServicio("http://"+ip+"/developDiego/verificar_entrada.php?placa=");



            }
        });
    }
    public void VerificarServicio(String URL){
        String PLACA=edtPlaca.getText().toString().trim();
        URL=URL+PLACA;
        RequestQueue queue = Volley.newRequestQueue(registro_salida.this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String estado = jsonObject.getString("estado");

                        if ("existe".equals(estado)) {
                            Toast.makeText(registro_salida.this, "El vehículo ya está dentro del parqueadero", Toast.LENGTH_SHORT).show();
                            consulta1("http://"+ip+"/developDiego/consulta.php?placa=");
                        } else {
                            Toast.makeText(registro_salida.this, "El vehículo no esta dentro ", Toast.LENGTH_SHORT).show();
                            // Aquí puedes llamar tu función para registrar entrada
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(registro_salida.this, "Error en la respuesta", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(registro_salida.this, "Error al conectar con el servidor", Toast.LENGTH_SHORT).show();
                });

        queue.add(stringRequest);
    }
    public void consulta1(String URL) {
        String PLACA=edtPlaca.getText().toString().trim();
        URL=URL+PLACA;
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        if(jsonObject.getString("tipo").equals("Hora")){
                            modalidad.setText(modalidad.getText()+"Hora");
                            String fechaStr1=jsonObject.getString("fecha_hora_entrada");
                            String fechaStr2 = HORA.getText().toString().trim();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

                            LocalDateTime fecha1 = LocalDateTime.parse(fechaStr1, formatter);
                            LocalDateTime fecha2 = LocalDateTime.parse(fechaStr2, formatter);

                            Duration duracion = Duration.between(fecha1, fecha2);

                            long horas = duracion.toHours();
                            float Cobrar=horas*tarifa;
                            precio.setText(precio.getText()+String.valueOf(Cobrar));
                            String Cobrado=String.valueOf(Cobrar);
                            String id_entrada=jsonObject.getString("id_entrada");
                            insertar_salidas("http://"+ip+"/developDiego/insertar_salidas.php",fechaStr2,Cobrado,id_entrada);
                        }
                        else{
                            modalidad.setText(modalidad.getText()+"Mensualidad");
                            precio.setText(precio.getText()+"0");
                            String Cobrado="0";
                            String id_entrada=jsonObject.getString("id_entrada");
                            String fechaStr2 = HORA.getText().toString().trim();
                            insertar_salidas("http://"+ip+"/developDiego/insertar_salidas.php",fechaStr2,Cobrado,id_entrada);
                        }



                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Error de conexion", Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
    public void insertar_salidas(String URL, String fecha,String cobrar,String id_1){
        StringRequest stringRequest= new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion Exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("id_entrada",id_1);
                parametros.put("fecha",fecha);
                parametros.put("cobrar",cobrar);
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    }

