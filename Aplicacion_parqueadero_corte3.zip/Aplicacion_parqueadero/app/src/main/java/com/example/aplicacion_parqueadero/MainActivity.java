package com.example.aplicacion_parqueadero;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onClick(View view){
        Intent irLayout=null;
        if(view.getId()==R.id.btnClientes){
            irLayout= new Intent(MainActivity.this,clientes.class);
        }
        if(view.getId()==R.id.btnEmpleados){
            irLayout= new Intent(MainActivity.this,empleados.class);
        }
        if(view.getId()==R.id.btnVehiculos){
            irLayout= new Intent(MainActivity.this,vehiculos.class);
        }
        if(view.getId()==R.id.btnRegistroParqueo){
            irLayout= new Intent(MainActivity.this,operacion.class);
        }
        if(view.getId()==R.id.btnListar){
            irLayout= new Intent(MainActivity.this,visualizar.class);
        }
        startActivity(irLayout);
    }

}
