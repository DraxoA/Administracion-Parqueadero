package com.example.aplicacion_parqueadero;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.content.Intent;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class vehiculos extends AppCompatActivity {
    RequestQueue requestQueue;
    String cedulaCliente=null;
    EditText edtPlaca,edtModelo,edtMarca;
    Button btnRegistrarvehiculos;

    TextView titulo;

    AutoCompleteTextView desplegable;
    ArrayAdapter<String> adapterItems;
    ArrayList<String> items= new ArrayList<>();

    String ip=Globalinfo.ip;
    String Tipo="Mensualidad";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vehiculos);

        edtPlaca=(EditText)findViewById(R.id.editTextPlaca1);
        edtModelo=(EditText)findViewById(R.id.editTextModelo1);
        edtMarca=(EditText)findViewById(R.id.editTextMarca1);
        btnRegistrarvehiculos=(Button)findViewById(R.id.btn_registroVehiculos);
        titulo=(TextView)findViewById(R.id.textView);

        cargarCedulas("http://"+ip+"/developDiego/getId_clientes.php");

        desplegable = findViewById(R.id.cedula_clientes);
        adapterItems= new ArrayAdapter<String>(this,R.layout.list_item,items);
        desplegable.setAdapter(adapterItems);
        desplegable.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item= parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "Item: "+item,Toast.LENGTH_SHORT).show();
                cedulaCliente=item.toString();
            }
        });
        btnRegistrarvehiculos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean camposValidos = true;

                if (edtPlaca.getText().toString().trim().isEmpty()) {
                    edtPlaca.setBackgroundColor(Color.parseColor("#FFCDD2")); // rojo claro
                    camposValidos = false;
                } else {
                    edtPlaca.setBackgroundColor(Color.parseColor("#FFFFFFFF")); ;
                }

                if (edtModelo.getText().toString().trim().isEmpty()) {
                    edtModelo.setBackgroundColor(Color.parseColor("#FFCDD2"));
                    camposValidos = false;
                } else {
                    edtModelo.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                }
                if (edtMarca.getText().toString().trim().isEmpty()) {
                    edtMarca.setBackgroundColor(Color.parseColor("#FFCDD2"));
                    camposValidos = false;
                } else {
                    edtMarca.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                }

                if (!camposValidos) {
                    Toast.makeText(vehiculos.this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                ejecutarServicio("http://"+ip+"/developDiego/insertar_vehiculos.php");

                edtPlaca.setText("");
                edtModelo.setText("");
                edtMarca.setText("");
                edtPlaca.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                edtModelo.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
                edtMarca.setBackgroundColor(Color.parseColor("#FFFFFFFF"));;
            }
        });
    }
    private void ejecutarServicio(String URL){
        String PLACA=edtPlaca.getText().toString().trim();
        String MODELO=edtModelo.getText().toString().trim();
        String MARCA=edtMarca.getText().toString().trim();

        StringRequest stringRequest= new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion Exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("cedula_dueño",cedulaCliente);
                parametros.put("placa_vehiculo",PLACA);
                parametros.put("modelo_vehiculo",MODELO);
                parametros.put("marca_vehiculo",MARCA);
                parametros.put("Tipo_Cliente",Tipo);
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    private void cargarCedulas(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        //Aqui debo poner lo del array
                        items.add(jsonObject.getString("Cedula"));
                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Error de conexion",Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
}